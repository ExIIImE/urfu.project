const PRODUCTS = [
  {id:1, n:'Наушники Pulse', c:'Аудио', p:4990, e:'🎧', h:225},
  {id:2, n:'Умная лампа Lumo', c:'Умный дом', p:1890, e:'💡', h:48},
  {id:3, n:'Часы Tick S', c:'Носимые', p:7490, e:'⌚', h:150},
  {id:4, n:'Powerbank 20 000', c:'Зарядки', p:2390, e:'🔋', h:20},
  {id:5, n:'Колонка Boom Mini', c:'Аудио', p:3290, e:'🔊', h:280},
  {id:6, n:'Розетка Wi-Fi', c:'Умный дом', p:990, e:'🔌', h:190},
  {id:7, n:'Браслет Fit Go', c:'Носимые', p:2990, e:'📿', h:340},
  {id:8, n:'Зарядка 65 Вт', c:'Зарядки', p:1590, e:'⚡', h:60}
];
const $ = s => document.querySelector(s);
const money = n => n.toLocaleString('ru-RU') + ' ₽';
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

/* ---- уведомление ---- */
function toast(t) {
  const el = $('#toast');
  el.textContent = t; el.classList.add('on');
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('on'), 2200);
}

/* ---- карточки товаров ---- */
const cardHTML = p => `<article class="card">
  <div class="pic">${p.e}</div>
  <h3>${p.n}</h3><span class="cat">${p.c}</span>
  <div class="row"><b>${money(p.p)}</b><button data-add="${p.id}">В корзину</button></div></article>`;

function renderList() {
  const q = $('#q').value.trim().toLowerCase(), c = $('#cat').value, s = $('#sort').value;
  let list = PRODUCTS.filter(p => p.n.toLowerCase().includes(q) && (!c || p.c === c));
  if (s) list.sort((a, b) => s === 'asc' ? a.p - b.p : b.p - a.p);
  $('#list').innerHTML = list.map(cardHTML).join('');
  $('#empty').hidden = list.length > 0;
}
$('#popular').innerHTML = PRODUCTS.slice(0, 4).map(cardHTML).join('');
[...new Set(PRODUCTS.map(p => p.c))].forEach(c => $('#cat').add(new Option(c, c)));
['#q', '#cat', '#sort'].forEach(s => $(s).addEventListener('input', renderList));
renderList();

/* ---- корзина (localStorage) ---- */
function updateCart() {
  $('#cartN').textContent = cart.length;
  localStorage.setItem('cart', JSON.stringify(cart));
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-add]');
  if (!b) return;
  const p = PRODUCTS.find(x => x.id == b.dataset.add);
  cart.push(p.id); updateCart();
  toast(`«${p.n}» добавлен в корзину`);
});
updateCart();

/* ---- роутер (hash) ---- */
function route() {
  const r = (location.hash.replace('#/', '') || 'home');
  const id = ['catalog', 'contacts'].includes(r) ? r : 'home';
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('show', p.id === id));
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('on', a.dataset.r === id));
  $('#nav').classList.remove('open');
  window.scrollTo(0, 0);
}
addEventListener('hashchange', route);
route();

$('.burger').addEventListener('click', e => {
  const open = $('#nav').classList.toggle('open');
  e.currentTarget.setAttribute('aria-expanded', open);
});

/* ---- формы: HTML5 + JS-валидация ---- */
function validate(form) {
  let ok = true;
  form.querySelectorAll('input,select,textarea').forEach(el => {
    el.setCustomValidity('');
    const v = el.value.trim();
    if (el.name === 'name' && /\d/.test(v)) el.setCustomValidity('Имя не должно содержать цифр');
    if (el.name === 'phone' && v && !/^\+?[\d\s()-]{10,15}$/.test(v)) el.setCustomValidity('Телефон: от 10 цифр, например +48 600 000 000');
    if (el.name === 'email' && v && !/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v)) el.setCustomValidity('Введите email в формате name@site.com');
    if (el.name === 'agree' && !el.checked) el.setCustomValidity('Нужно ваше согласие');
    const box = el.closest('.field'), err = box && box.querySelector('.err');
    if (box) box.classList.toggle('bad', !el.checkValidity());
    if (err) err.textContent = el.validationMessage;
    if (!el.checkValidity()) ok = false;
  });
  return ok;
}

document.querySelectorAll('form[data-form]').forEach(form => {
  form.addEventListener('input', () => form.dataset.touched && validate(form));
  form.addEventListener('submit', e => {
    e.preventDefault();
    form.dataset.touched = 1;
    if (!validate(form)) { toast('Проверьте поля формы'); form.querySelector(':invalid')?.focus(); return; }
    const data = Object.fromEntries(new FormData(form));
    data.date = new Date().toLocaleString('ru-RU');
    const key = form.dataset.form;                       // имитация БД
    const saved = JSON.parse(localStorage.getItem(key) || '[]');
    saved.push(data); localStorage.setItem(key, JSON.stringify(saved));
    const out = form.parentElement.querySelector('.out');  // имитация отправки
    out.textContent = 'Данные отправлены на сервер:\n' + JSON.stringify(data, null, 2);
    out.hidden = false;
    toast('Готово! Форма отправлена');
    form.reset(); delete form.dataset.touched;
    form.querySelectorAll('.err').forEach(x => x.textContent = '');
    form.querySelectorAll('.bad').forEach(x => x.classList.remove('bad'));
  });
});
